//
//  ForecastWeatherViewController.swift
//  MobiquityTest
//
//  Created by Bhogapurau MadhavaRao on 14/06/21.
//

import UIKit

class ForecastWeatherViewController: UIViewController {

    var viewModel : ForecastDetailViewModel?
    var detailsView : ForecastDetailView?
    required init(viewModel: ForecastDetailViewModel?)
    {
        super.init(nibName: nil, bundle: nil)
        self.viewModel = viewModel
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.backButtonTitle = "Back"
        self.title = "5 Day Forecast"
        configureUI()
        // Do any additional setup after loading the view.
    }
    

    func configureUI()
    {
        let navHt = self.navigationController?.navigationBar.frame.height ?? 0
       let tabbarHt = self.tabBarController?.tabBar.frame.height ?? 0
       
       let requiredHt = SCREEN_HEIGHT - (navHt + tabbarHt)

        detailsView = ForecastDetailView(frame: CGRect(x: 0, y: 0, width: SCREEN_WIDTH, height: requiredHt), viewModel: viewModel, delegate: self)
        self.view = detailsView
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension ForecastWeatherViewController : ForecastDetailViewDelegate
{
    func itemClicked() {
        
    }
}
