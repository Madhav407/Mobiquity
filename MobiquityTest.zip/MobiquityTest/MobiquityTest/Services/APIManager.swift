//
//  APIManager.swift
//  MobiquityTest
//
//  Created by Bhogapurau MadhavaRao on 12/06/21.
//

import Foundation

 struct Constants
{
    static let BASE_URL = "http://api.openweathermap.org/data/2.5/"
    static let API_KEY = "fae7190d7e6433ec3a45285ffcf55c86"
}

enum ServiceType : String
{
    case today
    case foreCast
}
enum APIError : Error {
    case requestFailed(Error?, Data? = nil)
    case serverError(Int?, Error?, Data? = nil)
    case invalidData
}

enum Result<T,U> where U : Error {
    case success(T)
    case failure(U)
    
}

//typealias Completion<T:Codable> = (Result<T, APIError>) -> Void


class APIManager : NSObject
{
    static let shared = APIManager()
    
    func executeService<T>(type:ServiceType, params: [String:String]?, completion: @escaping (Result<T, APIError>) ->Void) where T : Codable {
        //service call
        
        var urlComponents : URLComponents?
        switch type {
        case .today:
            urlComponents = URLComponents(string: Constants.BASE_URL + "weather?")
        case .foreCast :
            urlComponents = URLComponents(string: Constants.BASE_URL + "forecast?")
                }
        
        
        if params != nil
        {
            urlComponents?.queryItems = params!.map { (key, value) in
            URLQueryItem(name: key, value: value)
        }
        }
        urlComponents?.queryItems?.append(URLQueryItem(name:"appid" , value: Constants.API_KEY))
        let encodeComponents = urlComponents?.percentEncodedQuery?.replacingOccurrences(of: "+", with: "%2B")
        urlComponents?.percentEncodedQuery = encodeComponents
        //originalString.addingPercentEncoding(withAllowedCharacters:NSCharacterSet.urlQueryAllowed)

        if let url = urlComponents?.url
        {
        print("Query URL = \(url)")
        let request = URLRequest(url: url)
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            
            DispatchQueue.main.async {
                self.handleResponse(response: response , data: data, error: error, decodetype: T.self, completion: completion)
            }
//                completion(responseObject, nil)
            }
            task.resume()

        }

    }
    
    func handleResponse<T:Codable>(response: URLResponse?, data: Data?, error: Error?, decodetype: T.Type, completion: @escaping (Result<T, APIError>) ->Void)
    {
        
        if let data = data,                            // is there data
            let urlResponse = response as? HTTPURLResponse,  // is there HTTP response
            (200 ..< 300) ~= urlResponse.statusCode,         // is statusCode 2XX
            error == nil
        {
            do {
                let responseObject = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
                print("JSON Respnse = \(responseObject)")
                
                let codabelModel = try JSONDecoder().decode(decodetype, from: data)
                completion(Result.success(codabelModel))
            }catch
            {
                print("codable failed")
                completion(Result.failure(.invalidData))
            }
        }
        else
        {
            completion(Result.failure(.requestFailed(error, nil)))
        }
    
    }
    
    
}

