//
//  LocationsListViewModel.swift
//  MobiquityTest
//
//  Created by Bhogapurau MadhavaRao on 13/06/21.
//

import Foundation
import CoreData

class LocationsListViewModel: NSObject {
    
    var locationModel: LocationsModel?
    var bookmarkedLocations : [LocationModel]?
    var delegate: ListViewDelegate?
    
    init(model:LocationsModel?, delegate: ListViewDelegate? = nil) {

//        super.init()
//        self.updateLocationDelegate()
        self.locationModel = model
        LocationServices.shared.viewModelDelegate = delegate
    }
    
    func updateLocationDelegate()
    {
        LocationServices.shared.viewModelDelegate = self.delegate
    }
    
    func fetchCurrentLocationWeatherData(lat : Float? = nil, lon: Float? = nil)
    {
        var params = [String: String]()
        if lat == nil || lon == nil
        {
         params = ["lat" : String(describing: LocationServices.shared.currentLatitude ?? 0), "lon":String(describing: LocationServices.shared.currentLongitude ?? 0)]
        }
        else
        {
            params = ["lat" : String(describing: lat ?? 0), "lon":String(describing: lon ?? 0)]
        }
        APIManager.shared.executeService(type: .today, params: params) { (result : Result<LocationsModel, APIError>) in
            
            switch result
            {
            case .success( let model ) :
                print(model.coord?.lat)
                print(model.coord?.lon)
                print("succeess")
                self.locationModel = model
                self.saveLocationsForBookmarks(locationModel: model)
            
            case .failure(let error) :
                print(error)
            }
            
        }
    }
    
    func saveLocationsForBookmarks(locationModel: LocationsModel?)
    {
        if let locName = locationModel?.name
        {
            
        CoreDataManager.shared.insertLocation(latitude: locationModel?.coord?.lat ?? 0, longitude: locationModel?.coord?.lon ?? 0, locName: locName)
            DispatchQueue.main.asyncAfter(deadline: .now()+0.2) {
                self.fetchBookmarksLocationList()
            }
        }
        else
        {
            print("no current lcation to insert")
        }
    }
    
    
    func fetchBookmarksLocationList()
    {
        DispatchQueue.main.async {
            let locationList = CoreDataManager.shared.fetchBookmarkedLocations()
            self.bookmarkedLocations = locationList
            self.delegate?.refreshBookmarkedLocationsList()
        }
       
    }
    
    func prepareForecastSectionsData(model: ForecastDetailModel ) ->ForecastDetailViewModel
    {
        let result = ForecastDetailViewModel(forecastModel: model)
        return result
//        return ForecastDetailViewModel(forecastModel: model)
    }
}
