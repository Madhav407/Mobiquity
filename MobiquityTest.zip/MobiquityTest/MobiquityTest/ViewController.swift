//
//  ViewController.swift
//  MobiquityTest
//
//  Created by Bhogapurau MadhavaRao on 12/06/21.
//

import UIKit

let SCREEN_WIDTH = UIScreen.main.bounds.size.width
let SCREEN_HEIGHT = UIScreen.main.bounds.size.height

class ViewController: UIViewController {

    var viewModel: LocationsListViewModel?
    var  locView : LocationsListView?
    
    func fetchLocationsList(){
        self.locView?.fetchList()
    }
    
     required init(viewModel:LocationsListViewModel?) {
        super.init(nibName: nil, bundle: nil)
        if viewModel == nil
        {
            self.viewModel  =  LocationsListViewModel(model: nil, delegate: self)
        }
        else
        {
        self.viewModel = viewModel
        }
    }
    
    @IBAction func addLocationAction(_ sender: UIBarButtonItem) {
        
        
        let mapVC = self.storyboard?.instantiateViewController(identifier: "MapViewController") as? MapViewController
        mapVC?.delegate = self
        self.navigationController?.pushViewController(mapVC!, animated: true)
        
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    @IBAction func deleteAction(_ sender: UIBarButtonItem) {
        self.locView?.isEdit = true
        self.locView?.setTableViewEditMode(bool: true)
        updateDoneButton()
    }
    
    func updateEditButton()
    {
        let edit = UIBarButtonItem(title: "Edit", style: .plain, target: self, action: #selector(deleteAction(_:)))
        self.navigationItem.leftBarButtonItem = edit

    }
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
    
    @objc func doneButton(_ sender: UIBarButtonItem) {
        updateEditButton()
        self.locView?.setTableViewEditMode(bool: false)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Bookmarked List"
        

        configureUI()
        self.fetchLocationsList()
    }
    
    func updateDoneButton()
    {
        let done = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(doneButton(_:)))
        self.navigationItem.leftBarButtonItem = done

    }
    
    
    func configureUI()
    {
         let navHt = self.navigationController?.navigationBar.frame.height ?? 0
        let tabbarHt = self.tabBarController?.tabBar.frame.height ?? 0
        
        let rquiredHt = SCREEN_HEIGHT - (navHt + tabbarHt)
        locView = LocationsListView(frame: CGRect(x: 0, y: 0, width: SCREEN_WIDTH , height: rquiredHt), viewModel: self.viewModel, delegate: self)
        view = locView
    }

}

extension ViewController : ListViewDelegate
{
    func refreshBookmarkedLocationsList() {
        locView?.refreshLocationList(modelList: nil)
    }
    
    func locationSelected(location: LocationModel) {
        
        let params = ["lat" : String(describing: location.latitude ?? 0), "lon":String(describing: location.longitude ?? 0)]

        APIManager.shared.executeService(type: .foreCast, params: params) {(result : Result<ForecastDetailModel, APIError>) in
            switch result
            {
            
            case .success( let model ) :
                print("Success case forcast")
                let detailsViewModel = self.locView?.viewModel?.prepareForecastSectionsData(model: model)
                
                let detailsVC = ForecastWeatherViewController(viewModel: detailsViewModel)
                self.navigationController?.pushViewController(detailsVC, animated: true)
//                self.viewModel.
//                print(model.coord?.lon)
//                print("succeess")
//                self.locationModel = model
//                self.saveLocationsForBookmarks(locationModel: model)
            
            case .failure(let error) :
                print(error)
            }
        }
        
        
    }

    func updateNewBookMarkForSelectedLocationONMap(lat: Double, lon:Double)
    {
        let latitude = Float(lat)
        let longitude = Float(lon)
        self.locView?.viewModel?.fetchCurrentLocationWeatherData(lat: latitude, lon: longitude)
        
    }
    func updateBookMarkWhileLocationChanged() {
        self.locView?.fetchList()
    }
}


