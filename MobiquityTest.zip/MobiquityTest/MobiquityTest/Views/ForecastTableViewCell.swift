//
//  ForecastTableViewCell.swift
//  MobiquityTest
//
//  Created by Bhogapurau MadhavaRao on 14/06/21.
//

import UIKit

class ForecastTableViewCell: UITableViewCell {
    @IBOutlet weak var windLabel: UILabel!
    
    @IBOutlet weak var rainLabel: UILabel!
    @IBOutlet weak var humidityLabel: UILabel!
    @IBOutlet weak var cloudLabel: UILabel!
    @IBOutlet weak var tempLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
