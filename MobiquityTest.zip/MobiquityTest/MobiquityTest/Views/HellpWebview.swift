//
//  HellpWebview.swift
//  MobiquityTest
//
//  Created by Bhogapurau MadhavaRao on 14/06/21.
//

import UIKit
import WebKit
class HellpWebview: UIView {
    var webView : WKWebView
    
    override init(frame: CGRect) {
        webView = WKWebView(frame: frame)
        super.init(frame: frame)
        configureUI()

    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
        
    
    func configureUI()
    {
        self.addSubview(webView)
        
        let margins = self.safeAreaLayoutGuide
        webView.leadingAnchor.constraint(equalTo: margins.leadingAnchor).isActive = true
        webView.trailingAnchor.constraint(equalTo: margins.trailingAnchor).isActive = true
        webView.topAnchor.constraint(equalTo: margins.topAnchor).isActive = true
        webView.bottomAnchor.constraint(equalTo: margins.bottomAnchor).isActive = true
        webView.bottomAnchor.constraint(equalTo: margins.bottomAnchor, constant: 50).isActive = true
        
        loadHtmlContent()
    }
    
    func loadHtmlContent()
    {
        let localFilePath = Bundle.main.url(forResource: "HelpNotes", withExtension: "html")
           let request = NSURLRequest(url: localFilePath!)
           webView.load(request as URLRequest)
        
    }
   

}
