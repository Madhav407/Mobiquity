//
//  CustomViews.swift
//  MobiquityTest
//
//  Created by Bhogapurau MadhavaRao on 14/06/21.
//

import UIKit
extension UIView {
    
    
    
    class func loadFromNib<T: UIView>(tag: Int? = nil) -> T {
        var requiredView: T?

        if tag == nil
        {
            return (Bundle.main.loadNibNamed(String(describing: self), owner: nil, options: nil)?[0] as? T)!
        }
        
        
        if let list =
         Bundle.main.loadNibNamed(String(describing: self), owner: nil, options: nil) as? [T]
        {
            for view in list
            {
                if view.tag == tag
                {
                    requiredView = view
                    break
                }
            }
            return requiredView ?? UIView() as! T
        }
        return UIView() as! T
    }
}


class CustomViews: UIView {


    @IBOutlet weak var sectionTitleLabel: UILabel!
}
