//
//  WeatherLocationTableViewCell.swift
//  MobiquityTest
//
//  Created by Bhogapurau MadhavaRao on 13/06/21.
//

import UIKit

class WeatherLocationTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

//    @IBOutlet weak var tempLabel: UILabel!
    @IBOutlet weak var locationLabel: UILabel!
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
