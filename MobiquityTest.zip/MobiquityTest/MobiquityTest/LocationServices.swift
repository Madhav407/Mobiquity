//
//  LocationServices.swift
//  MobiquityTest
//
//  Created by Bhogapurapu MadhavaRao on 12/06/21.
//

import Foundation
import CoreLocation

class LocationServices : CLLocationManager, CLLocationManagerDelegate
{
    static let shared = LocationServices()
    var currentLatitude: Double?
    var currentLongitude: Double?
    var locManager : CLLocationManager?
    var authStatus : CLAuthorizationStatus?
    var viewModelDelegate : ListViewDelegate?
    
    func startLocationServices()
    {
        locManager = CLLocationManager()
        locManager?.desiredAccuracy = kCLLocationAccuracyBest
        locManager?.delegate = self
//        locManager?.requestWhenInUseAuthorization()
        locManager?.requestAlwaysAuthorization()
        locManager?.startUpdatingLocation()
    }
    
    override func stopUpdatingLocation() {
        locManager?.stopUpdatingLocation()
    }
    
    var currentLocation: CLLocation? {
      if let latitude = currentLatitude, let longitude = currentLongitude {
        return CLLocation(latitude: latitude, longitude: longitude)
      }
      return nil
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        print("auth status = \(status)")
        authStatus = status
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        //let currentLocation = locations.first
        print("curent lolcation coordinate = \(manager.location?.coordinate ?? CLLocationCoordinate2D(latitude: 0, longitude: 0))")
      let currentLocation = manager.location?.coordinate
    
        if currentLatitude != currentLocation?.latitude && currentLongitude != currentLocation?.longitude
        {
            currentLatitude = currentLocation?.latitude
            currentLongitude = currentLocation?.longitude

            self.viewModelDelegate?.updateBookMarkWhileLocationChanged()
//            let coord = Coord(lon: currentLongitude, lat: currentLatitude)
//            let locModel = LocationsModel(coord: coord, weather: nil, base: nil, main: nil, visibility: nil, wind: nil, clouds: nil, dt: nil, sys: nil, timezone: nil, id: nil, name: <#T##String?#>, cod: nil)
        }
        currentLatitude = currentLocation?.latitude
        currentLongitude = currentLocation?.longitude
//        self.stopUpdatingLocation()
    }

    
}
